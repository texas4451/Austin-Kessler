﻿
namespace CapstoneProjectWithUIMoneyConverterToWords
{
    partial class frmMoneyToWords
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMoneyInput = new System.Windows.Forms.Label();
            this.txtMoneyInput = new System.Windows.Forms.TextBox();
            this.lblMoneyInWords = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMoneyInput
            // 
            this.lblMoneyInput.AutoSize = true;
            this.lblMoneyInput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMoneyInput.Location = new System.Drawing.Point(58, 21);
            this.lblMoneyInput.Name = "lblMoneyInput";
            this.lblMoneyInput.Size = new System.Drawing.Size(98, 21);
            this.lblMoneyInput.TabIndex = 0;
            this.lblMoneyInput.Text = "Money Input";
            // 
            // txtMoneyInput
            // 
            this.txtMoneyInput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMoneyInput.Location = new System.Drawing.Point(58, 63);
            this.txtMoneyInput.Name = "txtMoneyInput";
            this.txtMoneyInput.Size = new System.Drawing.Size(173, 29);
            this.txtMoneyInput.TabIndex = 1;
            // 
            // lblMoneyInWords
            // 
            this.lblMoneyInWords.AutoSize = true;
            this.lblMoneyInWords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMoneyInWords.Location = new System.Drawing.Point(58, 107);
            this.lblMoneyInWords.Name = "lblMoneyInWords";
            this.lblMoneyInWords.Size = new System.Drawing.Size(127, 21);
            this.lblMoneyInWords.TabIndex = 2;
            this.lblMoneyInWords.Text = "Money in Words:";
            // 
            // lblOutput
            // 
            this.lblOutput.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblOutput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblOutput.Location = new System.Drawing.Point(58, 128);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(365, 117);
            this.lblOutput.TabIndex = 3;
            // 
            // btnAnswer
            // 
            this.btnAnswer.Location = new System.Drawing.Point(58, 248);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(75, 23);
            this.btnAnswer.TabIndex = 4;
            this.btnAnswer.Text = "Translate";
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(58, 281);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(379, 281);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMoneyToWords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 316);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.lblMoneyInWords);
            this.Controls.Add(this.txtMoneyInput);
            this.Controls.Add(this.lblMoneyInput);
            this.Name = "frmMoneyToWords";
            this.Text = "Money To Words";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMoneyInput;
        private System.Windows.Forms.TextBox txtMoneyInput;
        private System.Windows.Forms.Label lblMoneyInWords;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

