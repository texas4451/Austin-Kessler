﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapstoneProjectMoneyToWordConverter
{
    class MoneyToWords
    {
        //take input through IO of textbox
        //output at lblMoneyInWords

        public String ConversionOfNumber(String n)
        {
            //convert digits 1-9 to words
            int numPlaceHolder = Convert.ToInt32(n);
            String _numberInput = null;

            switch (numPlaceHolder)
            {
                case 1:
                    _numberInput = "One";
                    break;
                case 2:
                    _numberInput = "Two";
                    break;
                case 3:
                    _numberInput = "Three";
                    break;
                case 4:
                    _numberInput = "Four";
                    break;
                case 5:
                    _numberInput = "Five";
                    break;
                case 6:
                    _numberInput = "Six";
                    break;
                case 7:
                    _numberInput = "Seven";
                    break;
                case 8:
                    _numberInput = "Eight";
                    break;
                case 9:
                    _numberInput = "Nine";
                    break;
                case 10:
                    _numberInput = "Ten";
                    break;
                case 11:
                    _numberInput = "Eleven";
                    break;
                case 12:
                    _numberInput = "Twelve";
                    break;
                case 13:
                    _numberInput = "Thirteen";
                    break;
                case 14:
                    _numberInput = "Fourteen";
                    break;
                case 15:
                    _numberInput = "Fifteen";
                    break;
                case 16:
                    _numberInput = "Sixteen";
                    break;
                case 17:
                    _numberInput = "Seventeen";
                    break;
                case 18:
                    _numberInput = "Eighteen";
                    break;
                case 19:
                    _numberInput = "Nineteen";
                    break;
                case 20:
                    _numberInput = "Twenty";
                    break;
                case 30:
                    _numberInput = "Thirty";
                    break;
                case 40:
                    _numberInput = "Fourty";
                    break;
                case 50:
                    _numberInput = "Fifty";
                    break;
                case 60:
                    _numberInput = "Sixty";
                    break;
                case 70:
                    _numberInput = "Seventy";
                    break;
                case 80:
                    _numberInput = "Eighty";
                    break;
                case 90:
                    _numberInput = "Ninety";
                    break;
                default:
                    if (numPlaceHolder > 0)
                    {
                        _numberInput = ConversionOfNumber(n.Substring(0, 1) + "0") + " " + ConversionOfNumber(n.Substring(1));
                    }
                    break;
            }
            return _numberInput;
        }

/*           public String ConversionOfTens(String n)
        {
            //convert 10s places into words
            //make sure 10-19 have individual words
            //every 10s place can be accomotaded by a ones place number
            int numPlaceHolder = Convert.ToInt32(n);
            String _numberInput = null;

            switch (numPlaceHolder)
            {
                case 10:
                    _numberInput = "Ten";
                    break;
                case 11:
                    _numberInput = "Eleven";
                    break;
                case 12:
                    _numberInput = "Twelve";
                    break;
                case 13:
                    _numberInput = "Thirteen";
                    break;
                case 14:
                    _numberInput = "Fourteen";
                    break;
                case 15:
                    _numberInput = "Fifteen";
                    break;
                case 16:
                    _numberInput = "Sixteen";
                    break;
                case 17:
                    _numberInput = "Seventeen";
                    break;
                case 18:
                    _numberInput = "Eighteen";
                    break;
                case 19:
                    _numberInput = "Nineteen";
                    break;
                case 20:
                    _numberInput = "Twenty";
                    break;
                case 30:
                    _numberInput = "Thirty";
                    break;
                case 40:
                    _numberInput = "Fourty";
                    break;
                case 50:
                    _numberInput = "Fifty";
                    break;
                case 60:
                    _numberInput = "Sixty";
                    break;
                case 70:
                    _numberInput = "Seventy";
                    break;
                case 80:
                    _numberInput = "Eighty";
                    break;
                case 90:
                    _numberInput = "Ninety";
                    break;
                default:
                    if (numPlaceHolder > 0)
                    {
                        _numberInput = ConversionOfTens(n.Substring(0, 1) + "0") + " " + ConversionOfOnes(n.Substring(1));
                    }
                    break;
            }
            return _numberInput;
        }
*/

        public String ConvertionOfCents(String n)
        {
            //read places after decimal point as done from in front of decimal point
            //only return first two decimal places
            String convertedDecimal = null;
            String placementOfDecimal = null;
            String valueOfDecimal = null;

            for (int i = 0; i < n.Length; i++)
            {
                placementOfDecimal = n[i].ToString();

                if (placementOfDecimal.Equals("0"))
                {
                    valueOfDecimal = "Zero";
                }
                else
                {
                    valueOfDecimal = ConversionOfNumber(placementOfDecimal);
                }
                convertedDecimal += " " + valueOfDecimal;
            }
            return convertedDecimal;
        }

        public String ConvertionOfEntireWholeNumber(String n)
        {
            String _numberInput = null;
            double decimalPlace = Convert.ToDouble(n);
            bool completionOfTranslation = false;

            if (decimalPlace > 0)
            {
                int numberLength = n.Length;
                String placeValue = null;//place word of value of place after numbers when needed
                int elementOfNumber = 0;//changes according to place of digits being translated

                switch (numberLength)
                {
                    case 1:
                        _numberInput = ConversionOfNumber(n);
                        completionOfTranslation = true;
                        break;
                   /* case 2:
                        _numberInput = ConversionOfTens(n);
                        completionOfTranslation = true;
                        break;*/
                    case 3:
                        //add "hundred" at the end of numbers containing a hundred
                        elementOfNumber = 1;
                        placeValue = " Hundred ";
                        break;
                    case 4:
                    case 5:
                    case 6:
                        //add "thousand" at the end of numbers containing a thousand
                        elementOfNumber = (numberLength % 4) + 1;
                        placeValue = " Thousand ";
                        break;
                    case 7:
                    case 8:
                    case 9:
                        //add "million" at the end of numbers containing a million
                        elementOfNumber = (numberLength % 7) + 1;
                        placeValue = " Million ";
                        break;
                    case 10:
                    case 11:
                    case 12:
                        //add "billion" at the end of numbers containing a billion
                        elementOfNumber = (numberLength % 10) + 1;
                        placeValue = " Billion ";
                        break;
                    case 13:
                        if (elementOfNumber > numberLength % 11 + 1)//return invalid if over a billions place
                        {
                            return "That is an invalid output";
                        }
                        break;
                    case 14:
                        if (_numberInput == "-")//return invalid if negative
                        {
                            return "please do not enter negative numbers";
                        }
                        break;
                    default:
                        completionOfTranslation = true;
                        break;
                }

                if (!completionOfTranslation)
                {
                    if (n.Substring(0, elementOfNumber) != "0" && n.Substring(elementOfNumber) != "0")//accounts for 0's in beginning elements as part of the number
                    {
                        _numberInput = ConvertionOfEntireWholeNumber(n.Substring(0, elementOfNumber)) + " " + placeValue + " " + ConvertionOfEntireWholeNumber(n.Substring(elementOfNumber));
                    }
                    else
                    {
                        _numberInput = ConvertionOfEntireWholeNumber(n.Substring(0, elementOfNumber)) + " " + ConvertionOfEntireWholeNumber(n.Substring(elementOfNumber));
                    }
                }
            }
            return _numberInput;
        }
        //take user input
        //fail if number over billions
        //fail if negative
    }
}

public class ConvertingMoneyToWords
{
    public CapstoneProjectWithUIMoneyConverterToWords.MainProgram MainProgram
    {
        get => default;
        set
        {

        }
    }
}