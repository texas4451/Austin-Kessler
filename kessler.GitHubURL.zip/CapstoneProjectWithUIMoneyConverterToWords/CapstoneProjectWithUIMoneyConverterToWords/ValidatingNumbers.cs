﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kessler.ClassroomFullOfStudents.App02
{
    class ValidatingNumbers
    {
        public ValidatingNumbers() { }//default constructor

        public bool canBeInt(String s)
        {
            try
            {
                Convert.ToInt32(s);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool canBePositiveInt(String s)
        {
            try
            {
                if (Convert.ToInt32(s) > -1)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
    }

    public class ValidateNumbers
    {
        public ConvertingMoneyToWords ConvertingMoneyToWords
        {
            get => default;
            set
            {
            }
        }
    }
}
