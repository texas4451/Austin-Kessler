﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kessler.ClassroomFullOfStudents.App02
{
    class InputtingAndOutputting
    {
        public InputtingAndOutputting() { }  //default constructor

        public void showMessageToUser(String message)
        {
            Console.WriteLine(message);
        }

        public String receiveDataFromUser(String message)
        {
            Console.Write(message + "  ");
            return Console.ReadLine();
        }
    }

    public class InputOutput
    {
        public ConvertingMoneyToWords ConvertingMoneyToWords
        {
            get => default;
            set
            {
            }
        }
    }
}
