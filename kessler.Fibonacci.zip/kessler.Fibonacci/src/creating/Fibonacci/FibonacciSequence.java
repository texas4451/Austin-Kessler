package creating.Fibonacci;

import javax.swing.JOptionPane;

public class FibonacciSequence
{
	public FibonacciSequence()
	{
		listingTheNumbers();
	}

	public void listingTheNumbers()
	{
		// initialize list to 45 elements
		int numList = 45;
		String outputNumber = "";
		// establish first two variables of a=1 and b=1
		int a = 0;
		int b = 1;
		int c;

		int[] arrayOfSequence;

		arrayOfSequence = new int[numList];

		// ask user to input numbers
		for (int n = 1; n < arrayOfSequence.length; n++)
		{
			String userResponse = JOptionPane.showInputDialog(
					"Would you like to find more numbers to the Fibonacci Sequence?\n[y]\tYes\n[n]\tNo\n[q]\tQuit");

			if (userResponse.compareTo("y") == 0)
			{
				// acquire the sum of the two variables
				c = a + b;
				// for every element, add the sum of the last two elements to the end of the
				// list
				a = b;
				b = c;

				// place sum into next element of list
				arrayOfSequence[n] = c;
				
				//correlate which element has which value
				System.out.println("Element # " + n + " is " + c);

				// display list after every input
				outputNumber += arrayOfSequence[n];

				if (n < arrayOfSequence.length - 1)
				{
					outputNumber += ", ";
				}

				// new line when list hits seven inputs
				if (n % 7 == 0)
				{
					outputNumber += "\n";
				}
				//show first two numbers of the Fibonacci sequence before the user input numbers
				JOptionPane.showMessageDialog(null, "0, 1, " + outputNumber);
			}

			else if (userResponse.compareTo("n") == 0 || n == 45)
			{//shows user their final product of the Fibonacci Sequence before exiting the program
				JOptionPane.showMessageDialog(null, "Your final Fibonacci Sequence is\n" + outputNumber);
				break;
			}

			else if ((userResponse.compareTo("q") == 0))
			{//quits the program immediately
				JOptionPane.showMessageDialog(null, "Quitting...");
				break;
			}

			else
			{// let the user know their user was neither of the options and return them to
				// the main menu
				JOptionPane.showMessageDialog(null, "That was an invalid input : Returning to Select Menu");
			}
		}
	}
}